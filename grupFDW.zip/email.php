<?php
$haykaljb = 'haykalljb@gmail.com'; 
?>